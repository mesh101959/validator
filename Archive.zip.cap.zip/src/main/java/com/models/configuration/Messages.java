package com.models.configuration;

public  class Messages {

    public static final String FAILED_MESSAGE = "";

    public static final String MISSING_MANDATORY_FIELD_IN = "Missing mandatory field in ";
    public static final String BAD_FIELD_TYPE_IN = "Bad field type in ";
    public static final String HEADER_SECTION = "Header section";
    public static final String QUERY_PARAMS_SECTION = "Query params section";
    public static final String BODY_SECTION = "Body section";
}
