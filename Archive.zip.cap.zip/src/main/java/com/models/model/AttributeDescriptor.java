package com.models.model;

public record AttributeDescriptor(String name,
                                  String[] types,
                                  boolean required) {


}
