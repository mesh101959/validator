package com.models.model;

public record AbnormalFields(QueryParamsInput RequestParam, String reason) {
}
