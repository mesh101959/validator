package com.models.model;

public record QueryParamsInput(String name,
                               Object value) {
}
